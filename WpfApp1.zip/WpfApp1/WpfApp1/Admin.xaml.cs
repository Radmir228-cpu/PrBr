﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        private DispatcherTimer timer;
        private TimeSpan elapsedTime = TimeSpan.Zero;
        Entities.brEntities db =new Entities.brEntities();
        Entities.orders orders = new Entities.orders();
        public Admin()
        {
            InitializeComponent();
            Tab.IsReadOnly = true;
            db = new Entities.brEntities();
            Tab.ItemsSource = App.db.orders.ToList();
            updatat();

        }
        public void updatat()
        {
            Tab.ItemsSource = App.db.orders.ToList();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(100); // Обновление каждые 100 мс
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            timer.Stop();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            elapsedTime = elapsedTime.Add(timer.Interval);
            TimerLabel.Content = elapsedTime.ToString(@"hh\:mm\:ss");
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
