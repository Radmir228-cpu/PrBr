﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Reg.xaml
    /// </summary>
    public partial class Reg : Window
    {
        Entities.brEntities db;
        public Reg()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Staff staff = new Staff();
            staff.Show();
            this.Close();
            
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (login_tb.Text != null && surname_tb.Text != null && name_tb.Text != null && patronymic_tb.Text != null &&
                dr_dp.SelectedDate != null && series_tb.Text != null && number_tb.Text != null && address_tb.Text != null)
            {
                db = new Entities.brEntities();
                Entities.users users = new Entities.users
                {
                    email = login_tb.Text,
                    surname = surname_tb.Text,
                    name = name_tb.Text,
                    patronymic = patronymic_tb.Text,
                    date_of_brt = Convert.ToDateTime(dr_dp.SelectedDate),
                    series = series_tb.Text,
                    number = number_tb.Text,
                    address = address_tb.Text,
                };
                db.users.Add(users);
                db.SaveChanges();
                Staff staff = new Staff();
                staff.Show();
                MessageBox.Show("Данные добавленны");
              
            }
            else { MessageBox.Show("Заполните данные о клиенте", "", MessageBoxButton.OK, MessageBoxImage.Warning); }
        }

        private void series_tb_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Проверяем, является ли вводимый символ числом
            if (!char.IsDigit(e.Text, 0))
            {
                // Отменяем ввод, если символ не является числом
                e.Handled = true;
            }
        }

        private void number_tb_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Проверяем, является ли вводимый символ числом
            if (!char.IsDigit(e.Text, 0))
            {
                // Отменяем ввод, если символ не является числом
                e.Handled = true;
            }
        }

        private void dr_dp_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Проверка на цифры и точку
            if (!char.IsDigit(e.Text, 0) && e.Text != ".")
            {
                e.Handled = true;
                return;
            }

            // Проверка формата даты после каждого ввода символа
            string currentText = dr_dp.Text;
            if (currentText.Length > 0)
            {
                // Используйте регулярное выражение для проверки формата "ДД.ММ.ГГГГ"
                Regex regex = new Regex(@"^\d{1,2}\.\d{1,2}\.\d{4}$");

                if (regex.IsMatch(currentText))
                {
                    // Если дата соответствует формату, попробуйте преобразовать ее в DateTime
                    DateTime date;
                    if (DateTime.TryParseExact(currentText, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                    {
                        // Если преобразование успешно, установите выбранную дату в DatePicker
                        dr_dp.SelectedDate = date;
                    }
                    else
                    {
                        // Если преобразование не удалось, очистите текстовое поле DatePicker
                        dr_dp.Text = "";
                    }
                }
            }
        }
    }
}
