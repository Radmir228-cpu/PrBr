﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Staff.xaml
    /// </summary>
    public partial class Staff : Window
    {
        private DispatcherTimer timer;
        private TimeSpan elapsedTime = TimeSpan.Zero;
        Entities.brEntities db;
        
        public Staff()
        {
            InitializeComponent();
            db = new Entities.brEntities();
            
            var uslugi = db.equipment.Select(item=>item.name).ToList();
            foreach (var us in uslugi) { equipmnets_cb.Items.Add(us); }
            var user = db.users.Select(item=>item.surname).ToList();
            foreach (var use in user) { clients_cb.Items.Add(use); }
            var stafF = db.staff.Select(item => item.surname).ToList();
            foreach (var staf in stafF) { StaFF_cb.Items.Add(staf); }
            LoadLastValueAndIncrement();
           
        }

        private void LoadLastValueAndIncrement()
        {
           
        }
    
        

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(100); // Обновление каждые 100 мс
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            timer.Stop();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            elapsedTime = elapsedTime.Add(timer.Interval);
            TimerLabel.Content = elapsedTime.ToString(@"hh\:mm\:ss");
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void reg_bt_Click(object sender, RoutedEventArgs e)
        {
            Reg reg = new Reg();
            reg.Show();
            this.Close();
           
        }

        private void save_bt_Click(object sender, RoutedEventArgs e)
        {
            db = new Entities.brEntities();
            Entities.orders orders = new Entities.orders()
            {
               code = code_tb.Text,
               order_date = Convert.ToDateTime(order_dp.SelectedDate),
               order_time = order_time.Text,
               status = status_cb.Text,
               return_date = Convert.ToDateTime(return_dp.SelectedDate),
               time = time_tb.Text,
               id_equipment = Convert.ToInt32(equipmnets_cb.SelectedIndex+1),
               id_users = Convert.ToInt32(clients_cb.SelectedIndex+1),
               id_staff = Convert.ToInt32(StaFF_cb.SelectedIndex+1),

            };
            db.orders.Add(orders);
            db.SaveChanges();
            MessageBox.Show("Заказ добавлен!!! ", "", MessageBoxButton.OK, MessageBoxImage.Information);
           
        }

        private void order_time_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

        }

        private void time_tb_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Проверяем, является ли вводимый символ числом
            if (!char.IsDigit(e.Text, 0))
            {
                // Отменяем ввод, если символ не является числом
                e.Handled = true;
            }
        }

        

        private void time_tb_GotFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            textBox.SelectionStart = 3;
        }

        private void time_tb_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            var textBox = sender as TextBox;
            if (e.Key == Key.Back)
            {
                string currentText = textBox.Text;

                // Ищем последнюю цифру в строке
                int lastDigitIndex = currentText.LastIndexOfAny(new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' });

                // Если нашли цифру для замены
                if (lastDigitIndex != -1)
                {
                    currentText = currentText.Remove(lastDigitIndex, 1).Insert(lastDigitIndex, "_");
                    textBox.Text = currentText;

                    // Устанавливаем курсор на место удаления
                    textBox.SelectionStart = lastDigitIndex;
                }

                e.Handled = true; // Обрабатываем событие
            }
            else if (e.Key >= Key.D0 && e.Key <= Key.D9)
            {
                e.Handled = true; // Обрабатываем ввод цифр
                char digit = (char)(e.Key - Key.D0 + '0');
                string currentText = textBox.Text;
                int firstUnderscoreIndex = currentText.IndexOf('_');

                if (firstUnderscoreIndex != -1)
                {
                    currentText = currentText.Remove(firstUnderscoreIndex, 1).Insert(firstUnderscoreIndex, digit.ToString());
                    textBox.Text = currentText;
                    textBox.SelectionStart = firstUnderscoreIndex; // Устанавливаем курсор на место ввода

                    // Проверка количества введенных цифр
                    int digitCount = currentText.Count(c => char.IsDigit(c));
                    textBox.BorderBrush = digitCount >= 4 ? Brushes.Green : Brushes.Red;
                }
            }
            else
            {
                e.Handled = true; // Игнорируем все остальные клавиши
            }
        }
    }
}
