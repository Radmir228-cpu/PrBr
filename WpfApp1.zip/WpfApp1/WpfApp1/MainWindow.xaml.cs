﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.Entities;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Entities.brEntities db;
        int fail = 0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void pass_TextChanged(object sender, TextChangedEventArgs e)
        {
            passwordBox.Password = pass.Text;
        }

        private void passwordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            pass.Text = passwordBox.Password;

            // set the cursor position to 2...
            SetSelection(passwordBox, 40, 0);

            // focus the control to update the selection
            passwordBox.Focus();
        }
        private void SetSelection(PasswordBox passwordBox, int start, int length)
        {
            passwordBox.GetType().GetMethod("Select", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(passwordBox, new object[] { start, length });
        }

        private void SkritPokazpass_Click(object sender, RoutedEventArgs e)
        {
            if (im2.Visibility == Visibility.Collapsed)
            {
                im1.Visibility = Visibility.Collapsed;
                im2.Visibility = Visibility.Visible;
                pass.Visibility = Visibility.Visible;
                passwordBox.Visibility = Visibility.Collapsed;



            }
            else
            {
                im2.Visibility -= Visibility.Visible;
                im1.Visibility -= Visibility.Collapsed;
                pass.Visibility -= Visibility.Collapsed;
                passwordBox.Visibility -= Visibility.Collapsed;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            db = new Entities.brEntities();
            string email = emailTextBox.Text;
            string password = passwordBox.Password;
            if (email == "" &&  password == "")
            {
                MessageBox.Show("Введите свои данные");
            }
            else
            {
                if (db.staff.Any(x => x.login != email && x.password != password))
                {

                    if (db.staff.Any(x => x.login == email && x.password == password))
                    {
                        if (db.staff.Any(x => x.role == "Администратор" && x.login == email))
                        {
                            Admin admin = new Admin();
                            admin.Show();
                            admin.WindowState = this.WindowState;
                            this.Close();
                        }

                        else if (db.staff.Any(x => x.role == "Старший смены" && x.login == email))
                        {
                          
                           Staff staff = new Staff();
                            this.Close();
                            staff.Show();
                        }
                        else if (db.staff.Any(x => x.role == "Продавец" && x.login == email))
                        {
                           
                            Staff staff = new Staff();
                            staff.Show();
                            staff.WindowState = this.WindowState;
                            this.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль");
                        fail++;
                        if (fail == 3)
                        {

                            Captcha captcha = new Captcha();
                            captcha.Show();
                            this.Close();
                            fail = 0;
                        }
                    }
                }
            }
        }
    }
}
